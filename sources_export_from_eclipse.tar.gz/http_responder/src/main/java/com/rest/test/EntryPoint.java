package com.rest.test;

import java.io.IOException;

import java.io.PrintWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonValue;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParsingException;
import javax.json.JsonException;
import javax.json.JsonNumber;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;

@Path("/{urlRessource: .*}")

public class EntryPoint{

	private static Logger logger = Logger.getLogger(EntryPoint.class);
    
    // This function reads the JSON file and transform it according to the variable templating configuration defined in the configuration file    
    public static JsonArray parseJSONARRAYFile(String filename,String uniqueID) throws JsonException, IOException {
    	//String uniqueID = UUID.randomUUID().toString();
    	String myLogPrefix=uniqueID+" # --pJF-- ";
    	logger.trace(myLogPrefix+"Calling parseJSONARRAYFile with argument "+filename);
    	
        JsonArray myArray;
        try {
            //// BEGIN - convert file to Json
            String myResulFile=com.rest.test.GlobalParameters.getContentFileFromMemory(filename); // check if file in Memory
            InputStream is1;
            if (myResulFile==null)
            {   logger.trace(myLogPrefix+"Reading the file (For JSON Array conversion) "+filename);
            	File jsonInputFile = new File(filename); is1 = new FileInputStream(jsonInputFile); }
        	else
        	{   logger.trace(myLogPrefix+"Reading from memory an image of the file (For JSON Array conversion) "+filename);
        		is1=new ByteArrayInputStream(myResulFile.getBytes("UTF-8"));
        		//convert string to InputStream !
        	};
        	JsonReader reader1 = Json.createReader(is1);
            try { myArray = reader1.readArray(); reader1.close();is1.close();}
            catch (JsonException e)
            { logger.trace(myLogPrefix+"Convertion to JsonArray failed. A conversion to JsonObject will be made.");
              try   { reader1.close();is1.close();
              		  InputStream is2;
                      if (myResulFile==null)
                      {   logger.trace(myLogPrefix+"Reading the file (For JSON Object conversion) "+filename);
                    	  File jsonInputFile = new File(filename); is2 = new FileInputStream(jsonInputFile); }
                  	  else
                  	  {  logger.trace(myLogPrefix+"Reading from memory an image of the file (For JSON Object conversion) "+filename);
                  		 is2=new ByteArrayInputStream(myResulFile.getBytes("UTF-8"));
                  		 //convert string to InputStream !
                  	  };
            		  JsonReader reader2 = Json.createReader(is2);
            		  JsonObject  myTempObject = reader2.readObject(); reader2.close();is2.close();
            		  JsonObjectBuilder myTempObjectBuilder= Json.createObjectBuilder();
            		  for (Entry<String, JsonValue> itemJson : myTempObject.entrySet())
            		  {  myTempObjectBuilder.add(itemJson.getKey(), itemJson.getValue()); };
            		  myArray = Json.createArrayBuilder().add(myTempObjectBuilder).build();            				  
            }
              catch (JsonException e1)
            		{   logger.error(myLogPrefix+"The input file ("+filename+") used for generating the response body cannot be translated to JsonObject or JsonArray. It must be corrected. [{formatError:"+filename+"}] will be sent instead...");
                  		myArray = Json.createArrayBuilder().add(Json.createObjectBuilder().add("formatError", filename)).build();
            		}
            };
            //// END - convert file to Json
        	logger.trace(myLogPrefix+"Here's whats was read : "+myArray.toString());

        	JsonArray myArrayResult;
            JsonArrayBuilder builder = Json.createArrayBuilder();
            JsonObjectBuilder objBuilder = Json.createObjectBuilder();
            JsonObject myObj;
            final List<String> myIncrementKeysList=new ArrayList<String>(com.rest.test.GlobalParameters.getListIncrementKey());
            final List<String> myIncrementForWholeKeysList=new ArrayList<String>(com.rest.test.GlobalParameters.getListIncrementKeyForWhole());
            final List<String> myKeyToReplaceList=new ArrayList<String>(com.rest.test.GlobalParameters.getListKeyToReplace());
            final List<String> myChainToReplaceList=new ArrayList<String>(com.rest.test.GlobalParameters.getListChainToReplace());
            Integer hasAlreadyBeenIncremented = 0;
            logger.trace(myLogPrefix+"myKeyToReplaceList: "+myKeyToReplaceList.toString()+"\n");
            ///////////////////////////////////////////// BEGIN : LOOP on full JSON in file ///////////////////////////////////////////////////
            for (int i=0; i < myArray.size(); i++){
            	JsonObject itemArrInitial = (JsonObject) myArray.get(i);
            	logger.trace(myLogPrefix+"## loop "+i+" # value : "+itemArrInitial);
        		////////// START : Loop on Chain to replace ////
            	logger.trace(myLogPrefix+"   Processing : Chain To Replace");
            	Integer myRegExpFound = 0;
            	JsonObject tempJsonObject = null;
            	for (String myIndividualListString : myChainToReplaceList)  //id
        	    {  logger.trace(myLogPrefix+"  ## loop myIndividualListString = "+myIndividualListString);
        	       Pattern p = Pattern.compile(Pattern.quote(myIndividualListString));
        	       String myJsonString = itemArrInitial.toString();
        	       Matcher m = p.matcher(myJsonString);
        	       String myNewString;
        	       if (m.find())
        	       { myNewString = m.replaceAll(com.rest.test.GlobalParameters.getOneChainToReplace(myIndividualListString));
        	         myRegExpFound=1;
        	         logger.trace(myLogPrefix+"  -> String part written (chain to replace Found) : "+myNewString);
        	         JsonReader jsonReader = Json.createReader(new StringReader(myNewString));
        	         tempJsonObject = jsonReader.readObject();
        	         jsonReader.close();        	         
        	       } ;
        	    };
        	    JsonObject itemArr;
        	    if (myRegExpFound==1) {itemArr=tempJsonObject;}
        	    else {itemArr=itemArrInitial;};
            	//
                ////////// END : Loop on Chain to replace ////

        	    ///////////////////////////// BEGIN : Loop on each JSON Property ////////////////////////////////////////////////
        	    //itemArr.entrySet().forEach(itemArrIndividual ->  // Lambda loop (immutable) // Loop on each json property ex: loopID=3 
        	    logger.trace(myLogPrefix+"   Processing : IncrementKeys, IncrementKeysForWhole, KeysToReplace");
        	    for (Entry<String, JsonValue> itemArrIndividual : itemArr.entrySet())  // Loop on each json property ex: loopID=3
            	{   Integer itemWritten = 0;
            		logger.trace(myLogPrefix+"   ## loop itemArrIndividual = "+itemArrIndividual);
            		////////// START : Loop on Increment keys ////
            		for (String myIndividualListString : myIncrementKeysList)  //id
            	    {  logger.trace(myLogPrefix+"     ## loop (for IncrementKeys process) myIndividualListString = "+myIndividualListString);
            		   if (myIndividualListString.equals(itemArrIndividual.getKey()))
            		   {   /// 
            			   Integer myValueToWrite = com.rest.test.GlobalParameters.getOneIncrementKey(myIndividualListString);
            			   objBuilder.add(myIndividualListString,myValueToWrite);
            			   com.rest.test.GlobalParameters.incrementIncrementKey(myIndividualListString);  //increment for next 
            			   itemWritten = 1;
            			   logger.trace(myLogPrefix+"     JSON part written (incrementKey Found) : "+myIndividualListString+"="+myValueToWrite);
            			   break;
            		   };
            	    };
                    ////////// END : Loop on Increment keys ////
            	    ///
            		////////// START : Loop on Increment keys for whole ////
            		for (String myIndividualListString : myIncrementForWholeKeysList)  //id
            	    {  logger.trace(myLogPrefix+"     ## loop (for IncrementKeysForWhole process) myIndividualListString = "+myIndividualListString);
            		   if (myIndividualListString.equals(itemArrIndividual.getKey()))
            		   {   ///  
            			   Integer myValueToWrite;
            			   if (hasAlreadyBeenIncremented==0) 
            			   { myValueToWrite = com.rest.test.GlobalParameters.getOneIncrementKeyForWhole(myIndividualListString); 
            			     hasAlreadyBeenIncremented = myValueToWrite;
              			     com.rest.test.GlobalParameters.incrementIncrementKeyForWhole(myIndividualListString);  //increment for next
            			   } else { myValueToWrite = hasAlreadyBeenIncremented; } ;
            			   objBuilder.add(myIndividualListString,myValueToWrite);
            			   itemWritten = 1;
            			   logger.trace(myLogPrefix+"     JSON part written (incrementKeyForWhole Found) : "+myIndividualListString+"="+myValueToWrite);
            			   break;
            		   };
            	    };
                    ////////// END : Loop on Increment keys for whole////
            	    /////
            	    ////////// START : Loop on keys to replace ////
            		for (String myIndividualListString : myKeyToReplaceList)  //id
            	    {  logger.trace(myLogPrefix+"     ## loop (for KeysToReplace process)  myIndividualListString = "+myIndividualListString);
            		   if (myIndividualListString.equals(itemArrIndividual.getKey()))
            		   {   /// 
            			   String myValueToWrite = com.rest.test.GlobalParameters.getOneKeyToReplace(myIndividualListString);
            			   objBuilder.add(myIndividualListString,myValueToWrite);
            			   itemWritten = 1;
            			   logger.trace(myLogPrefix+"     JSON part written (key to replace Found) : "+myIndividualListString+"="+myValueToWrite);
            			   break;
            		   };
            	    };
                    ////////// END : Loop on keys to replace ////
            	    //
            	    if (itemWritten!=1)
            	    { //builder.add(Json.createObjectBuilder().add(itemArrIndividual.getKey(),itemArrIndividual.getValue()));
                 	  objBuilder.add(itemArrIndividual.getKey(),itemArrIndividual.getValue());
                 	 logger.trace(myLogPrefix+"     JSON part written (nothing found) : "+itemArrIndividual.getKey()+"="+itemArrIndividual.getValue());
            	    };
            	};
        	    ///////////////////////////// END : Loop on each JSON Property ////////////////////////////////////////////////
        		myObj=objBuilder.build();
        		logger.trace(myLogPrefix+"Object Written : myObj = "+myObj.toString());
        		builder.add(myObj); // building each individual JSON (line)
            }
            ///////////////////////////////////////////// END : LOOP on full JSON in file ///////////////////////////////////////////////////
            //
            myArrayResult = builder.build(); //building final result (multiple lines together)
            //
            logger.trace(myLogPrefix+"Exiting parseJSONARRAYFile returning : "+myArrayResult.toString());
            return myArrayResult;
            //return myArray;
        } catch (FileNotFoundException e) {   
        	    logger.error(myLogPrefix+"parseJSONARRAYFile : The input file ("+filename+") Cannot be opened. [{fileError:"+filename+"}] will be sent instead.", e);
         		myArray = Json.createArrayBuilder().add(Json.createObjectBuilder().add("fileError", filename)).build();
         		return myArray;
        }
    }

    // Similar to parseJSONARRAYFile but for a non JSON file. No templating will be applied. Called when the MIME type does not contains JSON
    public String parsePlainFile(String filename,String uniqueID) {
    	//String uniqueID = UUID.randomUUID().toString();
    	String myLogPrefix=uniqueID+" # --pPF-- ";
        logger.trace(myLogPrefix+"parsePlainFile has been called with the file : "+filename);
        String myStringLines=null;
        String myResulFile=com.rest.test.GlobalParameters.getContentFileFromMemory(filename); // check if file in Memory
        if (myResulFile==null)
        {	FileReader fileReader;
			try {  fileReader = new FileReader(filename);
		        BufferedReader bufferedReader = new BufferedReader(fileReader);
		        String line = null;
		        try {	while ((line = bufferedReader.readLine()) != null)
		                {
							if (myStringLines==null) {myStringLines=line;}
							else {myStringLines=myStringLines+"\n"+line;};
					    };
				        bufferedReader.close();
				        logger.trace(myLogPrefix+"Reading the file "+filename);
				} catch (IOException e) {  logger.error(myLogPrefix+"parsePlainFile : Problem reading the file "+filename+" . {fileError:"+filename+"} will be sent instead.", e);
										   return "{fileError:\""+filename+"\"}"; };	
			}
			catch (FileNotFoundException e) { 	logger.error(myLogPrefix+"parsePlainFile : The input file ("+filename+") Cannot be opened. {fileError:"+filename+"} will be sent instead.", e);
												return "{fileError:\""+filename+"\"}"; };
        } else {myStringLines=myResulFile;logger.trace(myLogPrefix+"Reading from memory an image of the file "+filename);};
		return myStringLines;
    }
    
    /////////////////// Writing Responses ///////////////////
    
    @Context private HttpServletResponse response4;
    @Context private HttpServletRequest request4;    

    @GET
    public void get() {	sendResponse(); };
    @PUT
    public void put() {	sendResponse(); };
    @POST
    public void post() {sendResponse(); };
    @DELETE
    public void delete() {sendResponse(); };    
    
    private void sendResponse() {
    	String uniqueID = UUID.randomUUID().toString();
    	String myLogPrefix=uniqueID+" # --sR--  ";
    	logger.trace(myLogPrefix+"Entering sendResponse");
    	
    	String theMimeType = com.rest.test.GlobalParameters.MIMEType;
    	if (theMimeType==null) {logger.fatal(myLogPrefix+"Attention : The MIME Type is null. Exiting the application.");System.exit(0); };
    	
    	response4.setContentType(theMimeType);

    	String myReceivedPath = request4.getPathInfo().replaceFirst("^\\/", "").replaceFirst("\\/$", "");
        String myReceivedMethod = request4.getMethod();
        List<Integer> myMatchingLines = com.rest.test.GlobalParameters.getFilteredUrlAndMethodLines(myReceivedPath,myReceivedMethod);        
        List<String> myConditions= new ArrayList<String>();
        int myRandom = (int) (Math.random()*100);

        logger.trace(myLogPrefix+"- Received Method : "+myReceivedMethod+" - Received Path : "+myReceivedPath+" - Matching lines in config file : "+myMatchingLines.toString()+" - Drawn random number (0,99) : "+myRandom );
        
        int myChosenLine = -1;
        int myMatchingBorder = 0;
        for (int i = 0; i<myMatchingLines.size(); i++)
        {	myMatchingBorder = myMatchingBorder+com.rest.test.GlobalParameters.getMyOnePercentageAL1(myMatchingLines.get(i));
        	if (myRandom<myMatchingBorder) { 	myChosenLine=myMatchingLines.get(i); break ; } ;
        } ;
        if (myChosenLine==-1)  // Not found - Let's try to match method with ANY
        {  myMatchingLines = com.rest.test.GlobalParameters.getFilteredUrlAndMethodLines(myReceivedPath,"ANY");
        	logger.trace(myLogPrefix+"- No match with regular pairing. Trying to match Method with ANY. - Matching lines in config file : "+myMatchingLines.toString() );
        	myMatchingBorder = 0; 
           for (int i = 0; i<myMatchingLines.size(); i++)
           {	myMatchingBorder = myMatchingBorder+com.rest.test.GlobalParameters.getMyOnePercentageAL1(myMatchingLines.get(i));
           		if (myRandom<myMatchingBorder) { 	myChosenLine=myMatchingLines.get(i); break ; } ;
           } ;
        };
        if (myChosenLine==-1)  // Not found - Let's try to match Url with ANY
        {  myMatchingLines = com.rest.test.GlobalParameters.getFilteredUrlAndMethodLines("ANY",myReceivedMethod);
        	logger.trace(myLogPrefix+"- No match with Method = ANY. Trying to match URL with ANY. - Matching lines in config file : "+myMatchingLines.toString() );
        	myMatchingBorder = 0; 
           for (int i = 0; i<myMatchingLines.size(); i++)
           {	myMatchingBorder = myMatchingBorder+com.rest.test.GlobalParameters.getMyOnePercentageAL1(myMatchingLines.get(i));
           		if (myRandom<myMatchingBorder) { 	myChosenLine=myMatchingLines.get(i); break ; } ;
           } ;
        };
        if (myChosenLine==-1)  // Not found - Let's try to match (Url,Method) with ANY
        {  myMatchingLines = com.rest.test.GlobalParameters.getFilteredUrlAndMethodLines("ANY","ANY");
           myMatchingBorder = 0; 
           logger.trace(myLogPrefix+"- No match with URL = ANY. Trying to match URL and Method with ANY. - Matching lines in config file : "+myMatchingLines.toString() );
           for (int i = 0; i<myMatchingLines.size(); i++)
           {	myMatchingBorder = myMatchingBorder+com.rest.test.GlobalParameters.getMyOnePercentageAL1(myMatchingLines.get(i));
           		if (myRandom<myMatchingBorder) { 	myChosenLine=myMatchingLines.get(i); break ; } ;
           } ;
        };
        if (myChosenLine==-1) // Still not found : Let's return a 405
        { 	PrintWriter out; response4.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        	try { out = response4.getWriter();out.flush(); } catch (IOException e) { logger.info(myLogPrefix+" Cannot send the 405 response"); }; 
        	logger.info(myLogPrefix+"- No Url + Method match. Sending back a SC_METHOD_NOT_ALLOWED (405)" );
        	return;  
        };
   	 	
        Integer myChosenReturnCode = com.rest.test.GlobalParameters.getMyOneResponseCodeAL1(myChosenLine);
        String myChosenPath = com.rest.test.GlobalParameters.getMyOnePathAL1(myChosenLine);
   	 	Integer myChosenDelay = com.rest.test.GlobalParameters.getMyOneTimeDelayAL1(myChosenLine);
        String myChosenReplace = com.rest.test.GlobalParameters.getMyReplaceAL1(myChosenLine);
        
   	    logger.info(myLogPrefix+"- Match for incoming paquet ("+myReceivedMethod+"#"+myReceivedPath+") ! Chosen line : "+myChosenLine+" from "+myMatchingLines.size()+" possibilities - Return Code : "+myChosenReturnCode+" - Return file for body: "+myChosenPath+" - Replace : "+myChosenReplace+" - Delay : "+myChosenDelay);
   	    
   	    ///////////////// BEGIN : Getting user variables //////////////////////////////////
   	    logger.trace(myLogPrefix+" # Getting User Variables");
   	    Map<String, String> mapReplace = new HashMap<String, String>();
   	    Map<String, String> mapUserVariable = new HashMap<String, String>();
   	    if (myChosenReplace!=null && myChosenReplace.length()>3)
   	    {	
   	    	List<String> myUserVariables = com.rest.test.GlobalVariables.getUserVariables();
		   	if (myUserVariables.size()>0)
		   	{		   		
		   		// Put conditions here
		   		try
		   	    {	String myBodyAsString = IOUtils.toString(request4.getInputStream());
		   	    	for (int i=0;i<myUserVariables.size();i++)
		   	    	{	String myWhereToSearch = com.rest.test.GlobalVariables.getVariableWhere(i);
		   	    		/////////////////////////////// into_body ////////////////////////////////////////////////////////////////////
		   	    		if (myWhereToSearch.equals("into_body"))
		   	    		{	String myRegex=com.rest.test.GlobalVariables.getVariablePattern(i);   
				   	    	if (myRegex != null)
				   	    	{	Pattern pat = Pattern.compile(myRegex); 
				   	    		//Pattern pat = Pattern.compile(com.rest.test.GlobalVariables.getVariablePattern(i)); 
			   	    			Matcher m1 = pat.matcher(myBodyAsString) ;
				   	    		if (m1.find())  //regex Found !
				   	    		{ logger.trace(myLogPrefix+"   - Regex "+myRegex+" Found!");
				   	    		  Integer myOccurence = Integer.parseInt(com.rest.test.GlobalVariables.getVariableOccurence(i));
				   	    		  //logger.trace(myLogPrefix+"myOccurence = "+myOccurence);
				   	    		  if (myOccurence==null) { myOccurence = 0;} ;
				   	    		  try
				   	    		  {	  String myKey = com.rest.test.GlobalVariables.getVariableName(i);
				   	    			  String myValue = m1.group(myOccurence);
				   	    		  	  mapUserVariable.put(myKey, myValue);
				   	    			  logger.trace(myLogPrefix+"   - New user variable (from body) written into mapUserVariable : ("+myKey+","+myValue+")"); 
				   	    		  } catch (IndexOutOfBoundsException e) { logger.error(myLogPrefix+"   # The specified occurence "+myOccurence+" throws an IndexOutOfBoundsException error");};
				   	    		}  
				   	    		else {logger.trace(myLogPrefix+"   - Regex "+myRegex+" NOT Found!");}; 
				   	    	};
		   	    		}
		   	    		/////////////////////////////// into_header ////////////////////////////////////////////////////////////////////
		   	    		else if (myWhereToSearch.equals("into_header"))
		   	    		{   String myKey = com.rest.test.GlobalVariables.getVariableName(i);
		   	    			String myHeaderValue=null;
		   	    			String myHeaderName=com.rest.test.GlobalVariables.getVariablePattern(i);   
			   	    		if (myHeaderName != null) {	myHeaderValue=request4.getHeader(myHeaderName); };
		   	    		  	mapUserVariable.put(myKey, myHeaderValue);
		   	    			logger.trace(myLogPrefix+"   - New user variable (from header) written into mapUserVariable : ("+myKey+","+myHeaderValue+")"); 
		   	    		}
		   	    		/////////////////////////////// into_url ////////////////////////////////////////////////////////////////////
		   	    		else if (myWhereToSearch.equals("into_url"))
		   	    		{   String myKey = com.rest.test.GlobalVariables.getVariableName(i);
		   	    			String myUrlValue=request4.getRequestURL().toString()+"?"+request4.getQueryString();
		   	    			String myRegex=com.rest.test.GlobalVariables.getVariablePattern(i);   
				   	    	if (myRegex != null)
				   	    	{	Pattern pat = Pattern.compile(myRegex); 
				   	    		//Pattern pat = Pattern.compile(com.rest.test.GlobalVariables.getVariablePattern(i)); 
			   	    			Matcher m1 = pat.matcher(myUrlValue) ;
				   	    		if (m1.find())  //regex Found !
				   	    		{ logger.trace(myLogPrefix+"   - Regex "+myRegex+" Found into URL !");
				   	    		  Integer myOccurence = Integer.parseInt(com.rest.test.GlobalVariables.getVariableOccurence(i));
				   	    		  //logger.trace(myLogPrefix+"myOccurence = "+myOccurence);
				   	    		  if (myOccurence==null) { myOccurence = 0;} ;
				   	    		  try
				   	    		  {	  
				   	    			  String myValue = m1.group(myOccurence); 
				   	    		  	  mapUserVariable.put(myKey, myValue);
				   	    			  logger.trace(myLogPrefix+"   - New user variable (from url) written into mapUserVariable : ("+myKey+","+myValue+")"); 
				   	    		  } catch (IndexOutOfBoundsException e) { logger.error(myLogPrefix+"   # For URL : The specified occurence "+myOccurence+" throws an IndexOutOfBoundsException error");};
				   	    		}  
				   	    		else {logger.trace(myLogPrefix+"   - Regex "+myRegex+" NOT Found into URL !");}; 
				   	    	};
	   	    				//logger.trace(myLogPrefix+"   - New user variable (from url) written into mapUserVariable : "+request4.getRequestURL().toString()+"?"+request4.getQueryString()); 
		   	    		};
		   	    	}	
				} catch (IOException e1) { 	logger.error(myLogPrefix+"IOException during User Variables - -IOUtils.toString(request4.getInputStream())",e1);}
		   	};
		   	String [] myParsedReplace = myChosenReplace.split("\\|");
		   	/// BEGIN // Populating myEltToReplace
		   	for (String myParsedReplaceElt : myParsedReplace)
		   	{  //logger.trace(myLogPrefix+"## AFAC ## "+myParsedReplaceElt); 
		   	   String [] myEltToReplace = myParsedReplaceElt.split("\\-\\>");
		   	   if (myEltToReplace.length==2)
		   	   {    String myKey = myEltToReplace[0];String myValue = myEltToReplace[1];
		   	   		/// BEGIN // Replace value when variable
		   	   		for (Map.Entry<String, String> p : mapUserVariable.entrySet())
		   	   		{ if (myValue.equals(p.getKey())) { myValue=p.getValue();}
		   	   		  else if (myValue.startsWith(p.getKey()+"."))
		   	   		  {  String [] myParsedParam = myValue.split("\\.");
		   	   		     if (myParsedParam.length==2)
		   	   		     {
		   	   		    	 String myValueInMapFile = com.rest.test.GlobalVariables.getMapLookupFile(p.getKey()+"#"+p.getValue());
		   	   		    	 if (myValueInMapFile!=null)
		   	   		    	 {  String [] mySplittedValueInMapFile = myValueInMapFile.split("\\|");
		   	   		    	 	Boolean mySubKeyNotFound=true;
		   	   		   			for (int i=0; i<mySplittedValueInMapFile.length;i++) 
		   	   		    		{	String [] myFinalSplittedValueInMapFile = mySplittedValueInMapFile[i].split("\\=");
		   	   		    			if (myFinalSplittedValueInMapFile.length==2)
		   	   		    			{   
		   	   		    				if (myParsedParam[1].equals(myFinalSplittedValueInMapFile[0]))
		   	   		    				{   myValue=myFinalSplittedValueInMapFile[1];
		   	   		    					mySubKeyNotFound=false;
		   	   		    				    //logger.trace(myLogPrefix+"##AFAC##  Should substitute with - "+myFinalSplittedValueInMapFile[1]);
		   	   		    				};
		   	   		    			}
		   	   		    			else
		   	   		    			{logger.error(myLogPrefix+" Parsing this element : "+myValue+" with '=' should yield to 2 elements.");};
		   	   		    		};	
   	   		    				if (mySubKeyNotFound) {logger.debug(myLogPrefix+"     The key was found ("+p.getKey()+"#"+p.getValue()+") , but no subKey : "+myParsedParam[1]);};
		   	   		    	 } else // try to find default
		   	   		    	 {  myValueInMapFile = com.rest.test.GlobalVariables.getMapLookupFile(p.getKey()+"#default");
				   	   		    String [] mySplittedValueInMapFile = myValueInMapFile.split("\\|");
		  	   		    		for (int i=0; i<mySplittedValueInMapFile.length;i++) 
		  	   		    		{	String [] myFinalSplittedValueInMapFile = mySplittedValueInMapFile[i].split("\\=");
		  	   		    			if (myFinalSplittedValueInMapFile.length==2)
		  	   		    			{
		  	   		    				if (myParsedParam[1].equals(myFinalSplittedValueInMapFile[0]))
		  	   		    				{   myValue=myFinalSplittedValueInMapFile[1];
		  	   		    				    //logger.trace(myLogPrefix+"##AFAC##  Should substitute with - "+myFinalSplittedValueInMapFile[1]);
		  	   		    				};
		  	   		    			}
		  	   		    			else
		  	   		    			{logger.error(myLogPrefix+" Parsing default. This element : "+myValue+" with '=' should yield to 2 elements.");};
		  	   		    		};	
		   	   		    	 };	 
		   	   		    	 //logger.trace(myLogPrefix+"##AFAC##   - "+myValueInMapFile);
		   	   		     }
		   	   		     else
		   	   		     {logger.error(myLogPrefix+" Parsing this element : "+myValue+" with '.' should yield to 2 elements.");};
		   	   		  };
		   	   		};
		   	   		/// END // Replace value when variable
		   		   	mapReplace.put(myKey, myValue);
		   		   	logger.trace(myLogPrefix+"   - New value written into mapReplace : ("+myKey+","+myValue+"). Derived from the condition : "+myParsedReplaceElt); 
		   	   }
		   	   else if (myParsedReplaceElt.startsWith("condition#"))
		   	   {   myConditions.add(myParsedReplaceElt.replaceFirst("condition\\#", ""));
		   	       logger.trace(myLogPrefix+" Condition found and added to myConditions : "+myParsedReplaceElt.replaceFirst("condition\\#", ""));
		   	   }
		   	   else if (myParsedReplaceElt.startsWith("addHeaderValue."))
		   	   {    String [] myHeaderToWrite=myParsedReplaceElt.replaceFirst("addHeaderValue\\.", "").split("\\:");
		   	   		if (myHeaderToWrite.length==2)
		   	   		{   String myValue;
	        		    String myVariableValue = mapUserVariable.get(myHeaderToWrite[1]);
	        		    if (myVariableValue!=null) { myValue=myVariableValue;}
	        		    else {myValue=myHeaderToWrite[1];};
		   	   			try { response4.addHeader(myHeaderToWrite[0], myValue);logger.trace(myLogPrefix+" New Header added : ("+myHeaderToWrite[0]+","+myValue+")");}
		   	   			catch (Exception e4) { logger.error(myLogPrefix+"Cannot set the new headers with :"+myParsedReplaceElt,e4);}					        		
		   	   		} 	else {logger.error(myLogPrefix+"Header not properly formated. We are especting 2 values separated by ':'. But we have : "+myParsedReplaceElt);};	
		   	   }
		   	   else { logger.error(myLogPrefix+" Parsing this element : "+myEltToReplace.toString()+" with '->' should yield to 2 elements.");};	   		   
		   	};
		    /// END // Populating myEltToReplace
   	    };
   	    ///////////////// END : Getting user variables //////////////////////////////////
	   	
    	response4.setStatus(myChosenReturnCode);
		if (myChosenDelay!=0) {try   { Thread.sleep(myChosenDelay); }  catch(InterruptedException ex)  { Thread.currentThread().interrupt(); }; };
   	 	PrintWriter out;
		try { out = response4.getWriter();
			  if (myChosenPath!=null && myChosenPath.length()>3)
			  {  //
				 String myStringLines;
				 if (theMimeType.toUpperCase().contains("JSON"))
				 {      myStringLines=parseJSONARRAYFile(myChosenPath,uniqueID).toString();
				 		if ((myStringLines.startsWith("[{\"formatError\":")) && (!myChosenPath.toUpperCase().endsWith(".JSON")))
				 		{  	logger.trace(myLogPrefix+"Since the file containing the body cannot be converted to JSON and the file does not end with '.json', we'll treat it like a non-json file.");
				 			myStringLines=parsePlainFile(myChosenPath,uniqueID); 
				 		}	;
				 }
				 else { myStringLines=parsePlainFile(myChosenPath,uniqueID);
				 };
				 //////// BEGIN ///////// Deal with conditions ////////////
				 for ( int k = 0; k < myConditions.size(); k++)
				 {  String [] myParsedCondition = myConditions.get(k).split("\\#");
				 	Boolean myConditionValidated=false;
				 	for ( int i =0; i < myParsedCondition.length; i++)
					{  
					   if (i==0)
					   {  String [] myUnitCondition = myParsedCondition[i].split("\\=");
						  if (myUnitCondition.length!=2) {logger.error(myLogPrefix+" myUnitCondition ("+myParsedCondition[i]+") should produce 2 values when split by '='.");}
						  else
						  { if (mapReplace.get(myUnitCondition[0])!=null && mapReplace.get(myUnitCondition[0]).equals(myUnitCondition[1]))
						    {  logger.trace(myLogPrefix+" Condition "+myParsedCondition[i]+" VALIDATED per interception of the replacement values !");
						        myConditionValidated=true;
						    }						    
						    else if (mapUserVariable.get(myUnitCondition[0])!=null && mapUserVariable.get(myUnitCondition[0]).equals(myUnitCondition[1]))
						    {	logger.trace(myLogPrefix+" Condition "+myParsedCondition[i]+" VALIDATED through Application Variables !");
					            myConditionValidated=true;
						    } else
						    {  logger.trace(myLogPrefix+" Condition "+myParsedCondition[i]+" NOT VALIDATED!");
						    }
						  };
					   } else //i!=0
					   { //logger.trace(myLogPrefix+" ## AFAC ## "+myParsedCondition[i]);
						 if  (myConditionValidated)
					     {  if (myParsedCondition[i].startsWith("changeHttpReturnCode:"))
					     	{ String myNewHttpStatus=myParsedCondition[i].replaceFirst("changeHttpReturnCode\\:", "");
					     	  try { response4.setStatus(Integer.parseInt(myNewHttpStatus)); logger.trace(myLogPrefix+" HTTP response changed to "+myNewHttpStatus);}
					     	  catch (NumberFormatException e1) { logger.error(myLogPrefix+"Cannot create a new HTTP response code with :"+myNewHttpStatus,e1);}
					     	}
					        else if (myParsedCondition[i].startsWith("changeBody:"))
					        {   String myNewBodyPath=myParsedCondition[i].replaceFirst("changeBody\\:", "");
					        	myStringLines=parsePlainFile(myNewBodyPath,uniqueID);logger.trace(myLogPrefix+" Body changed with "+myNewBodyPath);
					        }
					        else if (myParsedCondition[i].startsWith("changeMimeType:"))
					        {   String myNewMimeType=myParsedCondition[i].replaceFirst("changeMimeType\\:", "");
					            try { response4.setContentType(myNewMimeType);logger.trace(myLogPrefix+" MIME-Type changed to "+myNewMimeType);}
					     	    catch (Exception e2) { logger.error(myLogPrefix+"Cannot set the new Mime Type with :"+myNewMimeType,e2);}
					        }
					        else if (myParsedCondition[i].startsWith("addHeaderValue:"))
					        {   
					        	String myNewHeader=myParsedCondition[i].replaceFirst("addHeaderValue\\:", "");
					        	//logger.trace(myLogPrefix+" ### AFAC ### Header part : "+myNewHeader);
					        	String [] myHeaderToWrite = myNewHeader.split("\\:");
					        	if (myHeaderToWrite.length==2)
					        	{   String myValue;
					        		String myVariableValue = mapUserVariable.get(myHeaderToWrite[1]);
					        		if (myVariableValue!=null) { myValue=myVariableValue;}
					        		else {myValue=myHeaderToWrite[1];};
					        		try { response4.addHeader(myHeaderToWrite[0], myValue);logger.trace(myLogPrefix+" Header added : ("+myHeaderToWrite[0]+","+myValue+")");}
						     	    catch (Exception e3) { logger.error(myLogPrefix+"Cannot set the new headers Type with :"+myNewHeader,e3);}					        		
					        	} else { logger.error(myLogPrefix+" Parameters to create new header is wrong : "+myNewHeader);};
					        }					     
					        else {logger.trace(myLogPrefix+" Uknown instruction following Condition : "+myParsedCondition[i]);};
					     };
					   };
					};
				 };
				 //////// END ///////// Deal with conditions ////////////
				 //
				 // BEGIN : Transform the output
		   	   	 for (Map.Entry<String, String> p : mapReplace.entrySet())
		   	   	 { if (myStringLines!=null) {myStringLines=myStringLines.replaceAll(p.getKey(),p.getValue());};
		   	       logger.trace(myLogPrefix+" Replacing "+p.getKey()+" by "+p.getValue()+" into the answer's body");
		   	     };
				 // END : Transform the output
				 out.print(myStringLines);
			  } ;
			  out.flush();
	         logger.info(myLogPrefix+"- Sending response");			  
		} catch (IOException e) { logger.error(myLogPrefix+"sendResponse exception while building/sending the response.",e); } ;			
    }
 
}

package com.rest.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonReader;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GlobalParameters {
	
	 private static Logger logger = Logger.getLogger(GlobalParameters.class);
	
	 public static Map<String, Integer> mapIncrementKey = new HashMap<String, Integer>();
	 public static Map<String, Integer> mapIncrementKeyForWhole = new HashMap<String, Integer>();
	 public static Map<String, String> mapKeyToReplace = new HashMap<String, String>();
	 public static Map<String, String> mapChainToReplace = new HashMap<String, String>();	 
	 public static Map<String, String> mapLookupFile = new HashMap<String, String>();
	 public static Map<String, String> mapResponseFile = new HashMap<String, String>();
     /*
	 public static void initialyseMapLookupFile() {
		 String myLogPrefix="--iMLF--";
		 String myFile = com.rest.test.GlobalVariables.prop("response");
		 FileReader fileReader;
			try {  fileReader = new FileReader(myFile);
		        BufferedReader bufferedReader = new BufferedReader(fileReader);
		        String line = null;
		        try {	while ((line = bufferedReader.readLine()) != null)
		                {
							if (myStringLines==null) {myStringLines=line;}
							else {myStringLines=myStringLines+"\n"+line;};
					    };
				        bufferedReader.close();
				} catch (IOException e) {  logger.error(myLogPrefix+"parsePlainFile : Problem reading the file "+filename+" . {fileError:"+filename+"} will be sent instead.", e);
										   return "{fileError:\""+filename+"\"}"; };	
			}
			catch (FileNotFoundException e) { 	logger.error(myLogPrefix+"parsePlainFile : The input file ("+filename+") Cannot be opened. {fileError:"+filename+"} will be sent instead.", e);
												return "{fileError:\""+filename+"\"}"; }; 
	 }*/
	 
	 /// BEGIN LoadFilesInMemory
	 public static Boolean LoadFilesInMemory;
	 public static void initialyseLoadFilesInMemory() {
		 String myLogPrefix=" --iLFIM-- ";
		 String myLoadFilesInMemory = com.rest.test.GlobalVariables.prop("LoadFilesInMemory");
		 if (myLoadFilesInMemory==null) {logger.error("LoadFilesInMemory is null. Check configuration file.");LoadFilesInMemory=false;}
		 else if (myLoadFilesInMemory.equalsIgnoreCase("yes")) {logger.info("LoadFilesInMemory = yes");LoadFilesInMemory=true;}
		 else if (myLoadFilesInMemory.equalsIgnoreCase("no")) {logger.info("LoadFilesInMemory = no");LoadFilesInMemory=false;}
		 else {logger.error("LoadFilesInMemory value must be yes or no. Check configuration file.");LoadFilesInMemory=false;};
		 if (LoadFilesInMemory)
		 {   Integer myCpt=0;
			 List<String> myAllResponseFiles=getMyPathAL1();
			 for (String myIndividualReponseFile : myAllResponseFiles)
			 {  if (myIndividualReponseFile!=null && myIndividualReponseFile.length()>0)
			 	{     try {   byte[] encoded = Files.readAllBytes(Paths.get(myIndividualReponseFile));
							 String myFileContent = new String(encoded, StandardCharsets.UTF_8); 
							 mapResponseFile.put(myIndividualReponseFile, myFileContent);myCpt++;
				     	 }
						catch (IOException  e5) { 	logger.error(myLogPrefix+"Reading file "+myIndividualReponseFile+" Throws an error", e5); };
			 	};
			 }; logger.info(""+myCpt+" Response Files loaded in memory.");			 
		 }
	 }
	 public static Boolean getLoadFilesInMemory() {return LoadFilesInMemory;}
	 public static String getContentFileFromMemory(String key) {return mapResponseFile.get(key);}
	 /// END LoadFilesInMemory
	 
	 /// BEGIN MIMEType
	 public static String MIMEType;
	 public static void initialyseMIMEType() {
		 MIMEType = com.rest.test.GlobalVariables.prop("MIMEType");
		 if (MIMEType==null) {logger.warn("MIMEType is null. Check configuration file.");};
	 }
	 public static String getMIMEType() {return MIMEType;}
	 /// END MIMEType
	 
	 /// BEGIN response
	 public static List<String> myUrlMatchingAL1 = new ArrayList<String>();
	 public static List<String> myHttpMethodAL1 = new ArrayList<String>();
	 public static List<Integer> myResponseCodeAL1 = new ArrayList<Integer>();
	 public static List<Integer> myPercentageAL1 = new ArrayList<Integer>();
	 public static List<String> myPathAL1 = new ArrayList<String>();
	 public static List<String> myReplaceAL1 = new ArrayList<String>();
	 public static List<Integer> myTimeDelayAL1 = new ArrayList<Integer>();

	 public static void initialyseResponse() {
		 String myLogPrefix = "--iR-- Configuration Analysis - ";
		 String myUnparsedResponse = com.rest.test.GlobalVariables.prop("response");
		 if (myUnparsedResponse==null) {logger.fatal(myLogPrefix+"response is null in the configuration file. At least enter something like response=(ANY,ANY,200,100,,) to answer OK to all requests. Shut down of the Web-Server.");System.exit(0);};
		 String [] mySplittedResponse = myUnparsedResponse.split(";");
		 for (String elementWithParenthesis : mySplittedResponse)
		 {  String element = elementWithParenthesis.replaceFirst("^\\(", "").replaceFirst("\\)$","");
		    String [] mySplittedElement = element.split(",");
			if (mySplittedElement.length<4 ) {logger.fatal(myLogPrefix+"For response, the first 4 parameters are not optionnal. Shut down of the Web-Server.");System.exit(0);};
			///////////// 0 --> URL
			myUrlMatchingAL1.add(mySplittedElement[0]);
			///////////// 1 --> Method
			String [] myMethod = mySplittedElement[1].split("-");Arrays.sort(myMethod);
			String myTempString="";
			for (String myMethodElement : myMethod)
			{ if (myMethodElement.equals(myTempString)) {logger.fatal(myLogPrefix+"The method '"+myTempString+"' is duplicated. Shut down of the Web-Server.");System.exit(0);};
			  if (!myMethodElement.matches("GET|PUT|POST|DELETE|ANY")) {logger.fatal(myLogPrefix+"The method '"+myMethodElement+"' is incorrect. It must be GET, PUT, POST, PATCH, DELETE or ANY. Shut down of the Web-Server.");System.exit(0);}
			  if (myMethodElement.matches("ANY") && myMethod.length>1 ) {logger.fatal(myLogPrefix+"The method 'ANY' must be alone. Shut down of the Web-Server.");System.exit(0);}
			  myTempString=myMethodElement;
			};	
			String myConcatMethod = Arrays.toString(myMethod).replaceFirst("^\\[","").replaceFirst("\\]$","").replace(", ","#"); 
			myHttpMethodAL1.add(myConcatMethod);
			///////////// 2 --> Percentage
			myPercentageAL1.add(Integer.parseInt(mySplittedElement[2]));
			///////////// 3 --> http response code
			myResponseCodeAL1.add(Integer.parseInt(mySplittedElement[3]));
			//////// BEGIN - Check HTTP Code //////
			Field[] fields = HttpServletResponse.class.getFields();
	    	Integer myKnownHttpCode = 0;
			for (Field field : fields) { 
	    		field.setAccessible(true);//System.out.println("#"+field.getName()+"#"); 
	    		try {
  	              if (field.get(null).toString().equals(mySplittedElement[3])) {myKnownHttpCode++;} ;	    		
	    		} catch ( IllegalAccessException | SecurityException e) {
				  // TODO Auto-generated catch block
				  e.printStackTrace();
			    }
	    	};
	    	if (myKnownHttpCode!=1) {logger.fatal(myLogPrefix+"Unknown HTTP Code : "+mySplittedElement[3]+". Shut down of the Web-Server.");System.exit(0);} ;
			//////// END - Check HTTP Code //////
			///////////// 4-5-6 --> path-replace-delay
			if ( mySplittedElement.length>4  )
			{  myPathAL1.add(mySplittedElement[4]);			   
			     if ( mySplittedElement.length>5 )
			     {    myReplaceAL1.add(mySplittedElement[5]);
				      if ( mySplittedElement.length>6 ) { myTimeDelayAL1.add(Integer.parseInt(mySplittedElement[6])); }
			          else {myTimeDelayAL1.add(0);};
			     }     
		         else {myReplaceAL1.add(null); myTimeDelayAL1.add(0);};
			} else { myPathAL1.add(null);myReplaceAL1.add(null); myTimeDelayAL1.add(0); };	
		 };
		 /////  BEGIN : Verify percentage per URL type
		 //Set<String> myDistinctMatchingUrl = getDistinctMatchingUrlAL1();
		 Set<String> myDistinctMatchingUrlAndMethod = getDistinctUrlAndMethodAL1();
		 Iterator<String> iteratorDistinctMatchingUrlAndMethod = myDistinctMatchingUrlAndMethod.iterator();
		 while (iteratorDistinctMatchingUrlAndMethod.hasNext())
		 {	 String myOneDistinctMatchingUrlAndMethod = iteratorDistinctMatchingUrlAndMethod.next();
			 int mySum = 0;
			 for ( int k = 0; k < myPercentageAL1.size(); k++)
			 { if (myOneDistinctMatchingUrlAndMethod.equals(myUrlMatchingAL1.get(k)+";"+myHttpMethodAL1.get(k))) {mySum = myPercentageAL1.get(k) + mySum ;}; } ;
			 if (mySum!=100) {logger.fatal(myLogPrefix+"The sum of all percentages must be equal to 100 for "+myOneDistinctMatchingUrlAndMethod+" but it is equal to "+mySum+". Shutting down Web-Server now !");System.exit(0);};
		 }; 
		 logger.info(myLogPrefix+"There are "+myDistinctMatchingUrlAndMethod.size()+" distinct (URL + Method) configurations.");
		 /////  END : Verify percentage per URL type
		 //
		 /////  BEGIN : Verify Method Duplication per URL type
		 Set<String> myDistinctMatchingUrl = getDistinctMatchingUrlAL1();
		 Iterator<String> iteratorDistinctMatchingUrl = myDistinctMatchingUrl.iterator();
		 while (iteratorDistinctMatchingUrl.hasNext())
		 {	 String myOneDistinctMatchingUrl = iteratorDistinctMatchingUrl.next();
		 	 //System.out.println("####### Looping on URL : "+myOneDistinctMatchingUrl);
		 	 float hasGet = 0; float hasPost = 0; float hasPatch = 0; float hasPut = 0; float hasDelete = 0; 
			 for ( int k = 0; k < myHttpMethodAL1.size(); k++)
			 { if (myOneDistinctMatchingUrl.equals(myUrlMatchingAL1.get(k)))
			   { String myCorrespondingHttpMethod = myHttpMethodAL1.get(k);
			     //System.out.println("####### matching line : "+k+" # myCorrespondingHttpMethod = "+myCorrespondingHttpMethod);
			     int myCorrespondingPercentage = myPercentageAL1.get(k);
				 if (myCorrespondingHttpMethod.contains("GET")) { hasGet=hasGet + ((float) myCorrespondingPercentage)/100; }; 
				 if (myCorrespondingHttpMethod.contains("POST")) { hasPost=hasPost + ((float) myCorrespondingPercentage)/100; };
				 if (myCorrespondingHttpMethod.contains("PATCH")) { hasPatch=hasPatch + ((float) myCorrespondingPercentage)/100; };
				 if (myCorrespondingHttpMethod.contains("PUT")) { hasPut=hasPut + ((float) myCorrespondingPercentage)/100; };
				 if (myCorrespondingHttpMethod.contains("DELETE")) { hasDelete=hasDelete + ((float) myCorrespondingPercentage)/100; };
			   }; 
			  } ;
			 if (hasGet>1||hasPost>1||hasPatch>1||hasPut>1||hasDelete>1)
			 {logger.fatal(myLogPrefix+"One or several methods (GET,POST,PATCH,PUT or DELETE) appears more than once for URL "+myOneDistinctMatchingUrl+". ("+hasGet+","+hasPost+","+hasPatch+","+hasPut+","+hasDelete+") . Shuttind down Web-Server now !");System.exit(0);};
			 //else {System.out.println("####### OK method (GET,POST,PATCH,PUT or DELETE) for URL "+myOneDistinctMatchingUrl+". ("+hasGet+","+hasPost+","+hasPatch+","+hasPut+","+hasDelete+")");};
		 }; 
		 /////  END : Verify Method Duplication per URL type

	 }
	 public static List<String> getMyUrlMatchingAL1() {return myUrlMatchingAL1;}
	 public static List<String> getMyHttpMethodAL1() {return myHttpMethodAL1;}
	 public static List<Integer> getMyResponseCodeAL1() {return myResponseCodeAL1;}
	 public static List<Integer> getMyPercentageAL1() {return myPercentageAL1;}
	 public static List<String> getMyPathAL1() {return myPathAL1;}
	 public static List<String> getMyReplaceAL1() {return myReplaceAL1;}
	 public static List<Integer> getMyTimeDelayAL1() {return myTimeDelayAL1;}	 
	 //
	 public static String getMyOneUrlMatchingAL1(int i) {return myUrlMatchingAL1.get(i);}
	 public static String getMyOneHttpMethodAL1(int i) {return myHttpMethodAL1.get(i);}
	 public static Integer getMyOneResponseCodeAL1(int i) {return myResponseCodeAL1.get(i);}
	 public static Integer getMyOnePercentageAL1(int i) {return myPercentageAL1.get(i);}
	 public static String getMyOnePathAL1(int i) {return myPathAL1.get(i);}
	 public static String getMyReplaceAL1(int i) {return myReplaceAL1.get(i);}
	 public static Integer getMyOneTimeDelayAL1(int i) {return myTimeDelayAL1.get(i);}
	 //
	 public static List<Integer> hasMethod(String zeMethodToFind,List<String> zeFilteredMyHttpMethodAL1) {
		 // List the lines of the list (filtered or not) which contains the requested method (Ex:'GET') // ANY matches all !
		 List<Integer> myMatchingLinesAL1 = new ArrayList<Integer>();
		 for ( int k = 0; k < zeFilteredMyHttpMethodAL1.size(); k++)
		 { if (zeFilteredMyHttpMethodAL1.get(k).contains(zeMethodToFind)) {myMatchingLinesAL1.add(k);}; };
		 return myMatchingLinesAL1; 
	 }
	 public static Set<String> getDistinctMatchingUrlAL1() {
		 Set<String> myFilteredAL1 = new HashSet<String>();
		 for ( int k = 0; k < myUrlMatchingAL1.size(); k++)  { myFilteredAL1.add(myUrlMatchingAL1.get(k));}; 
		 return myFilteredAL1;		 
	 };
	 public static Set<String> getDistinctUrlAndMethodAL1() {
		 Set<String> myFilteredAL1 = new HashSet<String>();
		 for ( int k = 0; k < myUrlMatchingAL1.size(); k++)  { myFilteredAL1.add(myUrlMatchingAL1.get(k)+";"+myHttpMethodAL1.get(k));}; 
		 return myFilteredAL1;		 
	 };
	 /////// BEGIN Filtering on URL and URL+Method ///////////////////
	 public static List<Integer> getFilteredUrlLines(String zeUrlMatching) { // Return the index of the matching URL
		 List<Integer> myFilteredAL1 = new ArrayList<Integer>();
		 for ( int k = 0; k < myUrlMatchingAL1.size(); k++)
		 {  if ( myUrlMatchingAL1.get(k).equals(zeUrlMatching) ) { myFilteredAL1.add(k);}; };
		 return myFilteredAL1;
	 }
	 public static List<Integer> getFilteredUrlAndMethodLines(String zeUrlMatching, String zeMethod) { // Return the index of the matching URL+Method
		 //System.out.println("## getFilteredUrlAndMethodLines ");
		 List<Integer> myFilteredAL1 = new ArrayList<Integer>();
		 for ( int k = 0; k < myUrlMatchingAL1.size(); k++)
		 {  //System.out.println("## getFilteredUrlAndMethodLines Loop "+k);
		 	if (  ( (!myUrlMatchingAL1.get(k).matches("^\\*.*\\*$")) && (myUrlMatchingAL1.get(k).equals(zeUrlMatching)) )  // Url Matching (first line exact match - second : contains)
					||( (myUrlMatchingAL1.get(k).matches("^\\*.*\\*$")) && myUrlMatchingAL1.get(k).length()>2 && (zeUrlMatching.contains(myUrlMatchingAL1.get(k).substring(1,myUrlMatchingAL1.get(k).length()-1))) ) )
		    {  //System.out.println("## getFilteredUrlAndMethodLines Match URL for "+k+" # Calculate HasMethod to check the method");
			   List<String> myOneHttpMethod = new ArrayList<String>();
		       myOneHttpMethod.add(myHttpMethodAL1.get(k));
		       List<Integer> myResultList = hasMethod(zeMethod,myOneHttpMethod);  // Method Matching
		       Iterator<Integer> iteratorMyResultList = myResultList.iterator();
			   while (iteratorMyResultList.hasNext())
			   { //System.out.println("## getFilteredUrlAndMethodLines Writing matching line "+k);
				 myFilteredAL1.add(k); 
			     iteratorMyResultList.next(); //System.out.println("Matching Url and Method");
			   }; 			 
			   }
			};
		 return myFilteredAL1;
	 }
	 /////// END Filtering on URL and URL+Method ///////////////////
	 
	 /// END response
	 
	 public static void initialyseMapIncrementKey() {
		 String myIncrementKey = com.rest.test.GlobalVariables.prop("incrementKey");
		 if (myIncrementKey!=null)
		 {	 String [] myParsedIncrementKey = myIncrementKey.split(",");
			 for (String element : myParsedIncrementKey)
			 {	 if (element.split(":").length==2)
			     { mapIncrementKey.put(element.split(":")[0],Integer.parseInt(element.split(":")[1])) ; } //incrementKey=id:107,loopID:4
			     else {logger.fatal("Parameter initialisation - initialyseMapIncrementKey - For mapIncrementKey : The split by ':' should produce 2 values but it produces "+element.split(":").length+" # element = "+element.toString()+". Shuting down server now.");System.exit(0);};
			 };
		 } else {};
		 logger.info("Initialyse - mapIncrementKey : "+mapIncrementKey.toString());
	 };	 
	 
	 public static void initialyseMapIncrementKeyForWhole() {
		 String myIncrementKey = com.rest.test.GlobalVariables.prop("incrementKeyForWhole");
		 if (myIncrementKey!=null)
		 {	 String [] myParsedIncrementKey = myIncrementKey.split(",");
			 for (String element : myParsedIncrementKey)
			 {	 if (element.split(":").length==2)
		     	 { mapIncrementKeyForWhole.put(element.split(":")[0],Integer.parseInt(element.split(":")[1])) ; } //incrementKeyForWhole=id2:220,id3:66
		         else {logger.fatal("For mapIncrementKeyForWhole : The split by ':' should produce 2 values but it produces "+element.split(":").length+" # element = "+element.toString()+". Exiting Web-Server now.");System.exit(0);};
			 };
	     } else {};
	     logger.info("Initialyse - mapIncrementKeyForWhole : "+mapIncrementKeyForWhole.toString());
	 };	 
	 
	 public static void initialyseMapKeyToReplace() {
		 //System.out.println(com.rest.test.GlobalVariables.prop("incrementKey"));
		 String myIncrementKey = com.rest.test.GlobalVariables.prop("keyToReplace");
		 if (myIncrementKey!=null)
		 {	 String [] myParsedIncrementKey = myIncrementKey.split(",");
			 for (String element : myParsedIncrementKey)
			 {	 if (element.split(":").length==2)
	     	 	 {mapKeyToReplace.put(element.split(":")[0],element.split(":")[1]) ; } //keyToReplace=test:PIF,test1:PAF
	             else {logger.fatal("For mapKeyToReplace : The split by ':' should produce 2 values but it produces "+element.split(":").length+" # element = "+element.toString()+". Shut down of the Web-Service.");System.exit(0);};
			 };
	     } else {};
	     logger.info("Initialyse - mapKeyToReplace : "+mapKeyToReplace.toString());
	 };	 
	 
	 public static void initialyseMapChainToReplace() {
		 //System.out.println(com.rest.test.GlobalVariables.prop("incrementKey"));
		 String myIncrementKey = com.rest.test.GlobalVariables.prop("chainToReplace");
		 if (myIncrementKey!=null)
		 {	 String [] myParsedIncrementKey = myIncrementKey.split(",");
		 	 for (String element : myParsedIncrementKey)
			 {	 if (element.split(":").length==2)
     	 	 	 {mapChainToReplace.put(element.split(":")[0],element.split(":")[1]) ; } //chainToReplace=E4:E22,gentPro:NULL,[0-9]\=[0-9]:9\=9
                 else {logger.fatal("For mapChainToReplace : The split by ':' should produce 2 values but it produces "+element.split(":").length+" # element = "+element.toString());};
			 };
	     } else {};	
	     logger.info("Initialyse - mapChainToReplace : "+mapChainToReplace.toString());
	 };	 
	 
//////////////////////////////////////////////////////////////////////////////////////////////
	 
	 public static Integer incrementIncrementKey(String zeIncrementKey) {
		 Integer myVal = mapIncrementKey.get(zeIncrementKey+"_last");
		 if (myVal==null)		 
		 {   Integer myValOut = (mapIncrementKey.get(zeIncrementKey) == null ) ? 0 : mapIncrementKey.get(zeIncrementKey)+1; // if null ==> 0
			 mapIncrementKey.put(zeIncrementKey+"_last",mapIncrementKey.get(zeIncrementKey)+1); return myValOut;  }  
		 else
		 {mapIncrementKey.put(zeIncrementKey+"_last",myVal+1); return myVal+1;}
	 };

	 public static Integer incrementIncrementKeyForWhole(String zeIncrementKey) {
		 Integer myVal = mapIncrementKeyForWhole.get(zeIncrementKey+"_last");
		 if (myVal==null)		 
		 {   Integer myValOut = (mapIncrementKeyForWhole.get(zeIncrementKey) == null ) ? 0 : mapIncrementKeyForWhole.get(zeIncrementKey)+1; // if null ==> 0
		 	 mapIncrementKeyForWhole.put(zeIncrementKey+"_last",mapIncrementKeyForWhole.get(zeIncrementKey)+1); return myValOut;  }  
		 else
		 {mapIncrementKeyForWhole.put(zeIncrementKey+"_last",myVal+1); return myVal+1;}
	 };
	 
//////////////////////////////////////////////////////////////////////////////////////////////	 

	 public static Map<String, Integer> getWholeMapIncrementKey() {
		 return mapIncrementKey;
	 }
	 
	 public static Map<String, Integer> getWholeMapIncrementKeyForWhole() {
		 return mapIncrementKeyForWhole;
	 }
	 
	 public static Map<String, String> getWholeMapKeyToReplace() {
		 return mapKeyToReplace;
	 }

	 public static Map<String, String> getWholeMapChainToReplace() {
		 return mapChainToReplace;
	 }

//////////////////////////////////////////////////////////////////////////////////////////////
	 
	 public static Integer getOneIncrementKey(String zeIncrementKey) {
		 Integer myVal = mapIncrementKey.get(zeIncrementKey+"_last");
		 if (myVal==null)		 
		 {   Integer myValOut = (mapIncrementKey.get(zeIncrementKey) == null) ? 0 : mapIncrementKey.get(zeIncrementKey) ; //  if null ==> 0
			 return myValOut;  }  
		 else
		 {  return myVal;}
	 }

	 public static Integer getOneIncrementKeyForWhole(String zeIncrementKey) {
		 Integer myVal = mapIncrementKeyForWhole.get(zeIncrementKey+"_last");
		 if (myVal==null)		 
		 {   Integer myValOut = (mapIncrementKeyForWhole.get(zeIncrementKey) == null) ? 0 : mapIncrementKeyForWhole.get(zeIncrementKey) ; //  if null ==> 0
			 return myValOut;  }  
		 else
		 {  return myVal;}
	 }

	 public static String getOneKeyToReplace(String zeKeyToReplacey) {
		 String myVal = mapKeyToReplace.get(zeKeyToReplacey);
		 return myVal;
	 }

	 public static String getOneChainToReplace(String zeChainToReplacey) {
		 String myVal = mapChainToReplace.get(zeChainToReplacey);
		 return myVal;
	 }

//////////////////////////////////////////////////////////////////////////////////////////////	 
	 
	 public static List<String> getListIncrementKey() {
	     List<String> myTempStringArray=new ArrayList<String>(); 
		 mapIncrementKey.entrySet().forEach(unitaryIncrementKey -> {
			    //if (unitaryIncrementKey.getKey().length()>5) {System.out.println("Substring="+unitaryIncrementKey.getKey().substring(unitaryIncrementKey.getKey().length()-5));};
			    if (unitaryIncrementKey.getKey().length()>5 && unitaryIncrementKey.getKey().substring(unitaryIncrementKey.getKey().length()-5).equals("_last"))
	            {  }
	            else
	            {  myTempStringArray.add(unitaryIncrementKey.getKey()); } ;
		 });
		 return myTempStringArray;
	 }

	 public static List<String> getListIncrementKeyForWhole() {
	     List<String> myTempStringArray=new ArrayList<String>(); 
		 mapIncrementKeyForWhole.entrySet().forEach(unitaryIncrementKey -> {
			    //if (unitaryIncrementKey.getKey().length()>5) {System.out.println("Substring="+unitaryIncrementKey.getKey().substring(unitaryIncrementKey.getKey().length()-5));};
			    if (unitaryIncrementKey.getKey().length()>5 && unitaryIncrementKey.getKey().substring(unitaryIncrementKey.getKey().length()-5).equals("_last"))
	            {  }
	            else
	            {  myTempStringArray.add(unitaryIncrementKey.getKey()); } ;
		 });
		 return myTempStringArray;
	 }

	 public static List<String> getListKeyToReplace() {
	     List<String> myTempStringArray=new ArrayList<String>(); 
		 mapKeyToReplace.entrySet().forEach(unitaryKeyToReplace -> { myTempStringArray.add(unitaryKeyToReplace.getKey()); }) ;
		 return myTempStringArray;
	 }

	 public static List<String> getListChainToReplace() {
	     List<String> myTempStringArray=new ArrayList<String>(); 
		 mapChainToReplace.entrySet().forEach(unitaryChainToReplace -> { myTempStringArray.add(unitaryChainToReplace.getKey()); }) ;
		 return myTempStringArray;
	 }
}

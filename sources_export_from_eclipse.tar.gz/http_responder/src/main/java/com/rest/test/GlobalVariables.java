package com.rest.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

public class GlobalVariables {
  
	  public static final String myConfigFile = "ConfigurableHttpResponder.properties";
	  public static final String myExtDataPrefix = "externalLookupData.";
	  public static final String myUserVariablePrefix = "newApplicationVariable.";
	  private static final String mySep = "#separator#";
	  public static Map<String, String> mapLookupFile = new HashMap<String, String>();
	  
	  public static List<String> myUserVariables = new ArrayList<String>();
	  
	  private static Logger logger = Logger.getLogger(GlobalVariables.class);

	  public static String prop(String prop)
	  {
			Properties props = new Properties();
			InputStream input = null;
			try {
				input = new FileInputStream(myConfigFile);
				// load a properties file
				props.load(input);
			} catch (IOException ex) {
				logger.fatal("Calling GlobalVariables.props("+prop+"). Shut down of the Web-Server.",ex);System.exit(0);
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						logger.error("Calling GlobalVariables.props("+prop+")",e);
					}
				}
			};
			logger.trace("Calling GlobalVariables.props("+prop+"). Returns : "+props.getProperty( prop ));
			return props.getProperty( prop );
	  }

//// BEGIN : UserVariables Part //////////////////////////////////////////////////////	  
	  
	  public static void initialyseUserVariables()
	  {
		  List<String> myTempUserVariables = new ArrayList<String>();
		  Properties props = new Properties();
		  try
		  {
			  props.load(new FileInputStream(myConfigFile));
			  for (Enumeration<?> e = props.propertyNames(); e.hasMoreElements(); )
			  {   String name = (String)e.nextElement();
			      String value = props.getProperty(name);
			  	  if (name.startsWith(myUserVariablePrefix))
			      {  myTempUserVariables.add(name.replace(myUserVariablePrefix, "")+mySep+value);
			      }
			  }
		  } catch (IOException e1) { logger.fatal("Calling initialyseUserVariables(). Shut down of the Web-Server.",e1);System.exit(0);} ;
		  logger.info("initialyseUserVariables() has populated the variable : myUserVariables = "+myTempUserVariables.toString());
		  myUserVariables =  myTempUserVariables;		  
	  }
	  
	  public static List<String> getUserVariables() {return myUserVariables;}
	  
	  public static Integer getVariableIndex(String name) {
		  for (int i=0; i<myUserVariables.size();i++)
		  {  if (name.equals(myUserVariables.get(i).split(mySep)[0])) {return i;}  };
		  return null;
	  }
	  
	  public static String getVariableName(int i) {
		  if (i>=0 && i<myUserVariables.size()) {return myUserVariables.get(i).split(mySep)[0]; }
		  else {logger.error("getVariableName : i="+i+" and myUserVariables.size()="+myUserVariables.size());return null;}
	  }
	  
	  public static String getVariableWhere(int i) {
		  if (i>=0 && i<myUserVariables.size())
		  {   String[] temp=myUserVariables.get(i).split(mySep);
			  if (temp.length>=1) {return temp[1];} else {return null;}
		  }
		  else {logger.error("getVariableWhere : i="+i+" and myUserVariables.size()="+myUserVariables.size());return null;}
	  }
	  
	  public static String getVariableWhere(String name) {
		  return getVariableWhere(getVariableIndex(name));
	  }
	  
	  public static String getVariablePattern(int i) {
		  if (i>=0 && i<myUserVariables.size())
		  {   String[] temp=myUserVariables.get(i).split(mySep);
			  if (temp.length>=3) {return temp[2];} else {return null;}
		  }
		  else {logger.error("getVariablePattern : i="+i+" and myUserVariables.size()="+myUserVariables.size());return null;}
	  }
	  
	  public static String getVariablePattern(String name) {
		  return getVariablePattern(getVariableIndex(name));
	  }

	  public static String getVariableOccurence(int i) {
		  if (i>=0 && i<myUserVariables.size())
		  {   String[] temp=myUserVariables.get(i).split(mySep);
			  if (temp.length>=4) {return temp[3];} else {return null;}
		  }
		  else {logger.error("getVariableOccurence : i="+i+" and myUserVariables.size()="+myUserVariables.size());return null;}
	  }
	  
	  public static String getVariableOccurence(String name) {
		  return getVariableOccurence(getVariableIndex(name));
	  }

//// END : UserVariables Part //////////////////////////////////////////////////////	  

//// BEGIN : mapLookupFile // Initialyse + Get /////////////////////////////////////	  
	  public static void loadInMap()
	  {   String myLogPrefix="--lIM-- ";
	  	  //Map<String, String> mapLookupFile = new HashMap<String, String>();	  
		  Properties props = new Properties();
		  try {
			  props.load(new FileInputStream(myConfigFile));
			  for (Enumeration<?> e = props.propertyNames(); e.hasMoreElements(); )
			  {   String name = (String)e.nextElement();
			      String value = props.getProperty(name);
			      if (name.startsWith(myExtDataPrefix))
			      {
   			  	    logger.info(myLogPrefix+"Loading data "+name.replace(myExtDataPrefix, "")+" from external file : "+value);
			      	FileReader fileReader;
			      	int nbLookupValues=0;
			  		try {  fileReader = new FileReader(value);
			  	           BufferedReader bufferedReader = new BufferedReader(fileReader);
			  	           String line = null;
			  	           try {  while ((line = bufferedReader.readLine()) != null)
			  	                  {  String [] myLookUpElt = line.split(";");
	  								 if (myLookUpElt.length==2)
	  								 {  mapLookupFile.put(name.replace(myExtDataPrefix, "")+"#"+myLookUpElt[0], myLookUpElt[1]);
	  								    nbLookupValues++;
	  								 } else {logger.error(myLogPrefix+"Cannot parse line : "+line);};
			  				      };
			  				    logger.info(myLogPrefix+"Number of lines written in mapLookupFile : "+nbLookupValues)  ;
			  			        bufferedReader.close();
			  			   } catch (IOException e1) {  logger.error(myLogPrefix+"loadInMap : Problem reading the file "+value, e1);};	
			  		}
			  		catch (FileNotFoundException e2) { 	logger.error(myLogPrefix+"loadInMap : The input file ("+value+") Cannot be opened.", e2);};
			  		//logger.trace(myLogPrefix+" ## AFAC ##"+customPrint(mapLookupFile));			      
			      }
			   }
		} catch (IOException e2) { logger.error(myLogPrefix+"loadInMap : Problem reading the config file.", e2);};
	  }  

public static String getMapLookupFile(String myInput)	  
{
	return mapLookupFile.get(myInput);
}
//// END : mapLookupFile // Initialyse + Get /////////////////////////////////////	  
	  
	  
	  
	  
/////////////////////////// BELOW :  Just for Print	
	    	
	  public static String customPrint(Map<String, String> myMapArrayList) {
	  		String myReturn = "";
	  		for (String key : myMapArrayList.keySet())
	  		{  
	  			myReturn = myReturn+" [X] "+key+" => "+myMapArrayList.get(key);
	  		};
	  		return myReturn.replaceFirst("^ \\[X\\] ","");
	  	}
	    	
  	public static String customPrint(ArrayList<String> myArrayList) {
  		String myReturn = "";
  		for (String a : myArrayList) {  String stringNotNull = (a==null ? "" : a);
  										myReturn = myReturn+" | "+stringNotNull.substring(0,Math.min(55, stringNotNull.length()));}
  		return myReturn.replaceFirst("^ \\| ","");
  	}
  
  	public static String customPrint(List<String[]> myArrayList) {
  		String myReturn = "";
  		for (String [] a : myArrayList) {   myReturn = myReturn+" || "+customPrint(a);}
  		return myReturn.replaceFirst("^ \\|\\| ",""); 
  	}
  	
  	
  	public static String customPrint(String [] myArray) {
  		return customPrint(myArray, 55);
  	}

  	public static String customPrint(String [] myArray, Integer zeLength) {
  		String myReturn = "";
  		Integer myLength = (zeLength==null ? 55 : zeLength);
  		for ( String s : myArray) { String stringNotNull = (s==null ? "" : s);
  									myReturn = myReturn+" # "+stringNotNull.substring(0,Math.min(myLength, stringNotNull.length()));};
  		return myReturn.replaceFirst("^ # ","");
  	}
  		
  	public static String customPrint(String myStr, Integer myLength) {
  		String myReturn = "";
  		String stringNotNull = (myStr==null ? "" : myStr);
  		myReturn = stringNotNull.substring(0,Math.min(myLength, stringNotNull.length()));
  		return myReturn;
  	}

	  
}
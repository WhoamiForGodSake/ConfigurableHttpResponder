package com.rest.test;

import org.apache.log4j.Logger;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

//import com.rest.test.GlobalVariables;

public class App {

	private static Logger logger = Logger.getLogger(App.class);

    public static void main(String[] args) throws Exception {

    	String myParameter = null;
    	
    	if (args.length==1) {myParameter=args[0];};
    	
    	if (myParameter==null) {System.out.println("One and only one parameter is required - Choose from : help|run");}
    	else if (myParameter.toUpperCase().equals("RUN"))
    	{	Integer myPort = Integer.parseInt(com.rest.test.GlobalVariables.prop("port"));
	    	String myLogPrefix = "STARTING WEB-SERVER";
	    	logger.info(myLogPrefix+" on Port "+myPort+" ...");	
	    	myLogPrefix = "  Initialize";
	    	logger.info(myLogPrefix+" data from the file "+com.rest.test.GlobalVariables.myConfigFile);
	    	/// BEGIN : Initialize properties file retrieval
	    	com.rest.test.GlobalParameters.initialyseMapIncrementKey();
	    	com.rest.test.GlobalParameters.initialyseMapIncrementKeyForWhole();
	    	com.rest.test.GlobalParameters.initialyseMapKeyToReplace();
	    	com.rest.test.GlobalParameters.initialyseMapChainToReplace();
	    	com.rest.test.GlobalParameters.initialyseMIMEType();  //misplaced - just for test
	    	com.rest.test.GlobalParameters.initialyseResponse();  //misplaced - just for test
	    	com.rest.test.GlobalVariables.initialyseUserVariables();
	    	com.rest.test.GlobalVariables.loadInMap();
	    	com.rest.test.GlobalParameters.initialyseLoadFilesInMemory();
	    	/// END : Initialize properties file retrieval
	    	
	    	// BEGIN : For Debug
	    	myLogPrefix = "  Retrieved Parameters : ";logger.info(myLogPrefix);
	    	myLogPrefix = "    - ";logger.info(myLogPrefix+"MIME Type"+" : "+com.rest.test.GlobalParameters.getMIMEType());    	
	    	logger.info(myLogPrefix+"URL filter"+" : "+com.rest.test.GlobalParameters.getMyUrlMatchingAL1().toString());
	    	logger.debug(myLogPrefix+"Distinct URL filter"+" : "+com.rest.test.GlobalParameters.getDistinctMatchingUrlAL1().toString());
	    	logger.info(myLogPrefix+"HTTP Method filter"+" : "+com.rest.test.GlobalParameters.getMyHttpMethodAL1().toString());
	    	logger.info(myLogPrefix+"Percentage of answers chosen"+" : "+com.rest.test.GlobalParameters.getMyPercentageAL1().toString());
	    	logger.info(myLogPrefix+"HTTP Response Code"+" : "+com.rest.test.GlobalParameters.getMyResponseCodeAL1().toString());
	    	logger.info(myLogPrefix+"Path of the file containing the response body"+" : "+com.rest.test.GlobalParameters.getMyPathAL1().toString());
	    	logger.info(myLogPrefix+"Replace conditions : "+com.rest.test.GlobalParameters.getMyReplaceAL1().toString());
	    	logger.info(myLogPrefix+"Delay in milliseconds before sending answers"+" : "+com.rest.test.GlobalParameters.getMyTimeDelayAL1().toString());
	    	logger.info(myLogPrefix+"User variables : "+com.rest.test.GlobalVariables.getUserVariables().toString());
	    	// END  : For Debug
	    	
	    	ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
	        context.setContextPath("/");
	
	        //Server jettyServer = new Server(8080);
	        Server jettyServer = new Server(myPort);
	        jettyServer.setHandler(context);
	
	        ServletHolder jerseyServlet = context.addServlet(org.glassfish.jersey.servlet.ServletContainer.class, "/*");
	        jerseyServlet.setInitOrder(0);
	
	        // Tells the Jersey Servlet which REST service/class to load.
	        jerseyServlet.setInitParameter(
	           "jersey.config.server.provider.classnames",
	           EntryPoint.class.getCanonicalName());
	
	        try {
	            jettyServer.start();
	            jettyServer.join();
	        	myLogPrefix = "WEB-SERVER started.";logger.info(myLogPrefix);	
	        } finally {
	            jettyServer.destroy();
	            myLogPrefix = "WEB-SERVER stoped.";logger.info(myLogPrefix);
	        }
    	}
    	else if (myParameter.toUpperCase().equals("HELP"))
    	{	System.out.println("\nThis program takes one parameter which can be help or run.");
			System.out.println("\nPURPOSE :\nIt's a web server which is configured to send back a bespoke HTTP answer based on some parameters from an incoming HTTP request.");
			System.out.println("\nCONFIGURATION :\nConfigurableHttpResponder.properties has to be in the directory you are lauching the application from.\nSet it according to your needs (info about how to do so is included as comment in the file).");
			System.out.println("\nLOGS :\nBy default, the logs are set on TRACE (very verbose) and will be put into ConfigurableHttpResponder.log in the directory you're launching the application from.");
			System.out.println("If you want to overwrite the default log configuration, create a log4j.properties file where you're launching the application from and run the following command : java -jar -Dlog4j.configuration=file:/path/to/file http_responder-x.y.jar run");
			System.out.println("OR edit the log4j.properties file within the jar (with 7zip for example).\n");
			System.out.println("MORE INFO :\ngithub (look for 'ConfigurableHttpResponder').\n");
    	}
    	else {System.out.println("Wrong parameter - Choose from : help|run");};
    }
}

# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


admin:$1$JFIa4zWO$aaIoR1YzgKgggzrxV3I3A.:admin:none@gmail.com:admin,user

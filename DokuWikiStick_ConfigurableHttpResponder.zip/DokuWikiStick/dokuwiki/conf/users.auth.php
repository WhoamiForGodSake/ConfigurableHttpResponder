# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


rsala:$1$gJ4BmLj6$v17AzNvKE23FM/30cV263.:rsala:raphael.sala.work@gmail.com:admin,user
